const { app } = require('@azure/functions');
const { ClientSecretCredential } = require('@azure/identity');
const { Client } = require('@microsoft/microsoft-graph-client');
require('isomorphic-fetch');

app.http('ProcessOnboarding', {
    methods: ['POST'],
    authLevel: 'anonymous',
    handler: async (request, context) => {
        context.log('Received onboarding request...');

        try {
            const body = await request.json();
            const { name, email, department } = body;

            if (!name || !email) {
                return {
                    status: 400,
                    jsonBody: { error: "Missing required fields 'name' or 'email'" }
                };
            }

            // Authenticate with Microsoft Graph API using App Registration
            const credential = new ClientSecretCredential(
                process.env.AZURE_TENANT_ID,
                process.env.AZURE_CLIENT_ID,
                process.env.AZURE_CLIENT_SECRET
            );

            const authProvider = {
                getAccessToken: async () => {
                    const token = await credential.getToken('https://graph.microsoft.com/.default');
                    return token.token;
                }
            };

            const graphClient = Client.initWithMiddleware({ authProvider });

            // Construct Entra ID User payload
            const newUserPayload = {
                accountEnabled: true,
                displayName: name,
                mailNickname: email.split('@')[0],
                userPrincipalName: email,
                passwordProfile: {
                    forceChangePasswordNextSignIn: true,
                    password: "TempPassword123!"
                },
                department: department || 'General'
            };

            context.log(`Creating Entra ID user: ${newUserPayload.userPrincipalName}`);

            // Trigger Graph API Provisioning
            const createdUser = await graphClient.api('/users').post(newUserPayload);
            context.log(`Successfully created Entra ID user ID: ${createdUser.id}`);

            return {
                status: 200,
                jsonBody: {
                    success: true,
                    message: "User onboarded successfully",
                    userId: createdUser.id,
                    userPrincipalName: createdUser.userPrincipalName
                }
            };

        } catch (error) {
            // Print complete stack trace and details to Azure Application Logs
            context.error('CRITICAL ERROR in ProcessOnboarding:', error);

            // Extract Graph API error response body or fallback message
            const statusCode = error.statusCode || error.status || 500;
            let errorDetails = error.message;

            if (error.body) {
                try {
                    errorDetails = typeof error.body === 'string' ? JSON.parse(error.body) : error.body;
                } catch (e) {
                    errorDetails = error.body;
                }
            }

            return {
                status: statusCode,
                jsonBody: {
                    success: false,
                    error: "Microsoft Graph API or database operation failed",
                    details: errorDetails
                }
            };
        }
    }
});