const { app } = require('@azure/functions');

app.http('ProcessOnboarding', {
    methods: ['POST', 'GET'],
    authLevel: 'anonymous',
    handler: async (request, context) => {
        context.log('ProcessOnboarding function processed a request.');
        
        let body = {};
        if (request.method === 'POST') {
            body = await request.json();
        }

        return { 
            status: 200, 
            jsonBody: { 
                message: "Onboarding request processed successfully",
                data: body 
            } 
        };
    }
});