const { app } = require('@azure/functions');

app.http('ProcessOnboarding', {
    methods: ['POST', 'GET'],
    authLevel: 'anonymous',
    handler: async (request, context) => {
        context.log('Azure Function Triggered: HR Onboarding Process Started');

        try {
            let userData = {};
            if (request.method === 'POST') {
                userData = await request.json();
            } else {
                userData = { name: "Test User", email: "test@example.com", department: "Engineering" };
            }

            return {
                status: 200,
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({
                    status: "Success",
                    message: `Entra ID provisioning and SQL logging initiated for ${userData.name || 'User'}`,
                    roleAssigned: true
                })
            };
        } catch (error) {
            return {
                status: 400,
                body: JSON.stringify({ error: "Invalid request payload." })
            };
        }
    }
});