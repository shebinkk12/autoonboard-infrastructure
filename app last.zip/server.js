@'
const express = require('express');
const sql = require('mssql');
const path = require('path');
const cors = require('cors');

const app = express();
app.use(express.json());
app.use(cors());
app.use(express.static(path.join(__dirname)));

const config = {
    user: process.env.DB_USER || 'autodbuser2026',
    password: process.env.DB_PASS || 'AutoOnboard@2026#Pass',
    server: process.env.DB_HOST || 'sqlserver-autoonboard-01.database.windows.net',
    database: process.env.DB_NAME || 'sqldb-autoonboard',
    options: {
        encrypt: true,
        trustServerCertificate: false
    }
};

app.post('/api/onboard', async (req, res) => {
    const { name, email, department } = req.body;
    try {
        let pool = await sql.connect(config);
        await pool.request()
            .input('Name', sql.VarChar, name)
            .input('Email', sql.VarChar, email)
            .input('Department', sql.VarChar, department)
            .query('INSERT INTO Classmates (Name, Email, Department) VALUES (@Name, @Email, @Department)');
        res.status(200).json({ message: 'Success' });
    } catch (err) {
        console.error('SQL Error:', err);
        res.status(500).send('DB Error: ' + (err.message || 'Unknown error'));
    }
});

app.get('/api/classmates', async (req, res) => {
    try {
        let pool = await sql.connect(config);
        let result = await pool.request().query('SELECT * FROM Classmates ORDER BY Id DESC');
        res.status(200).json(result.recordset);
    } catch (err) {
        res.status(500).json([]);
    }
});

const PORT = process.env.PORT || 8080;
app.listen(PORT, () => console.log(`Server running on port ${PORT}`));
'@ | Out-File -FilePath server.js -Encoding utf8